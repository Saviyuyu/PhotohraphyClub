
document.getElementById('brandLogo').addEventListener('click', function(e) {
  e.preventDefault();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.addEventListener("DOMContentLoaded", () => {
  // Fade-in animation using IntersectionObserver
  const faders = document.querySelectorAll('.fade-in');

  const appearOnScroll = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  faders.forEach(fader => appearOnScroll.observe(fader));

  // Form submit handler
  const form = document.getElementById('joinForm');
  if (form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();

      // Save form values to localStorage
      localStorage.setItem('joinName', document.getElementById('name').value);
      localStorage.setItem('joinEmail', document.getElementById('email').value);
      localStorage.setItem('joinCourse', document.getElementById('course').value);
      localStorage.setItem('joinReason', document.getElementById('reason').value);

      // Redirect to thank you page
      window.location.href = 'thankyou.html';
    });
  }
});

